# README

## Project: Insurance Policy Management System

### Overview
This project is a simple Insurance Policy Management System implemented in Python. It allows users to:
Register and manage policyholders.
Create and update insurance products.
Process and track payments.

### Project Structure
policyholder.py: Handles policyholder registration, activation, and suspension.
product.py: Manages insurance products, including premium updates and suspension.
payment.py: Handles payment processing, reminders, penalties, and status updates.
main.py: Demonstrates usage of the system.

### nstallation and Setup
- Python 3.13
- Required library: None (Uses built-in libraries)
- Clone the repository:
- Navigate to the project directory:
- Run the program:

### Code Explanation

### 1. PolicyHolder Class (policyholder.py)
The PolicyHolder class manages policyholders' data and includes methods to:
Register new policyholders.
Suspend a policyholder.
Reactivate a suspended policyholder.

### 2. Product Class (product.py)
The Product class allows:
Creating new insurance products.
Updating product details.
Suspending products.

### 3. Payment Class (payment.py)

The Payment class includes methods to:
Process payments.
Send payment reminders.
Apply penalties for late payments.

### Demonstrating Policyholder Payments
The following script in main.py creates two policyholders, assigns them to an insurance product, processes payments, and displays their account details:

Expected Output:

### Usage
1. Registering a Policyholder
2. Creating an Insurance Product
3. Processing a Payment
4. Suspending a Policyholder
5. Sending a Payment Reminder

### Features
Register policyholders and update their status.
Create, update, and suspend insurance products.
Track payments, send reminders, and apply penalties.

### Future Enhancements
Implement a database for persistent data storage.
Develop a web-based user interface.
Integrate payment gateways for automated processing.

### License
This project is open-source under the MIT License.
### Author
Moses Kitimbo