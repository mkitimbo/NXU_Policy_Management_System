class Product:
    products = {}

    def __init__(self, product_id, name, description, price):
        try:
            self.id = product_id  # Ensuring ID consistency
            self.name = name
            self.description = description
            self.price = price  # Ensure price attribute exists

            Product.products[self.id] = self  # Store in class dictionary
            print(f"✅ Product '{self.name}' (ID: {self.id}) created successfully.")
        except Exception as e:
            print(f"❌ Error creating Product: {e}")

    @classmethod
    def create_product(cls, product_id, name, description, price):
        """Creates and registers a new product."""
        if product_id in cls.products:
            print(f"⚠️ Product ID {product_id} already exists.")
            return None
        return cls(product_id, name, description, price)

    def update_product(self, name=None, description=None, price=None):
        """Updates product details."""
        if name:
            self.name = name
        if description:
            self.description = description
        if price is not None:
            self.price = price
        print(f"🔄 Product '{self.name}' (ID: {self.id}) updated successfully.")

    def suspend_product(self):
        """Marks a product as suspended."""
        print(f"🛑 Product '{self.name}' (ID: {self.id}) has been suspended.")

    @classmethod
    def get_product(cls, product_id):
        """Retrieves a product by ID."""
        return cls.products.get(product_id, None)

    def get_details(self):
        """Returns product details as a formatted string."""
        return f"📦 Product(ID: {self.id}, Name: {self.name}, Price: {self.price})"

    def __str__(self):
        return self.get_details()
