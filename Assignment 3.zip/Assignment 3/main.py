from policyholder import PolicyHolder
from product import Product
from payment import Payment

def demonstrate_policyholder_payments():
    # Step 1: Register two policyholders
    policyholder1 = PolicyHolder.register(1786, "Anne Kitimbo", 28, "456 KMT St")
    policyholder2 = PolicyHolder.register(1379, "Moses Kitimbo", 40, "789 Bugema ")

    # Step 2: Create an insurance product
    product = Product.create_product(101, "Life Insurance", "Basic life coverage", 750)

    # Step 3: Process payments for both policyholders
    payment1 = Payment(201, policyholder1.id, product.price, "2025-03-20")
    payment2 = Payment(202, policyholder2.id, product.price, "2025-03-21")

    payment1.process_payment()
    payment2.process_payment()

    # Step 4: Display account details
    print("\n=== Policyholder Account Details ===")
    print(f"ID: {policyholder1.id}, Name: {policyholder1.name}, Status: {policyholder1.status}")
    print(f"ID: {policyholder2.id}, Name: {policyholder2.name}, Status: {policyholder2.status}")

demonstrate_policyholder_payments()
