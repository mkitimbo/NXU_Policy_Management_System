class Payment:
    payments = {}

    def __init__(self, payment_id, policyholder_id, amount, date, status="Pending"):
        try:
            self.payment_id = payment_id
            self.policyholder_id = policyholder_id
            self.amount = amount
            self.date = date
            self.status = status
            Payment.payments[payment_id] = self
            print(f"Payment {self.payment_id} created successfully.")
        except Exception as e:
            print(f"Error creating Payment: {e}")

    def process_payment(self):
        try:
            if self.status == "Paid":
                print(f"Payment {self.payment_id} has already been processed.")
            else:
                self.status = "Paid"
                print(f"Payment {self.payment_id} processed successfully.")
        except Exception as e:
            print(f"Error processing payment: {e}")

    def send_reminder(self):
        try:
            if self.status == "Pending":
                print(f"Reminder: Payment {self.payment_id} is due.")
            else:
                print(f"No reminder needed for Payment {self.payment_id}.")
        except Exception as e:
            print(f"Error sending reminder: {e}")

    def apply_penalty(self, penalty_amount):
        try:
            if self.status == "Pending":
                self.amount += penalty_amount
                print(f"Penalty of {penalty_amount} applied to Payment {self.payment_id}. New amount: {self.amount}")
            else:
                print(f"No penalty applied. Payment {self.payment_id} is already {self.status}.")
        except Exception as e:
            print(f"Error applying penalty: {e}")

    def mark_paid(self):
        try:
            self.status = "Paid"
            print(f"Payment {self.payment_id} marked as Paid.")
        except Exception as e:
            print(f"Error updating payment status: {e}")

    def mark_failed(self):
        try:
            self.status = "Failed"
            print(f"Payment {self.payment_id} marked as Failed.")
        except Exception as e:
            print(f"Error updating payment status: {e}")

    def __str__(self):
        return f"Payment(ID: {self.payment_id}, PolicyHolderID: {self.policyholder_id}, Amount: {self.amount}, Status: {self.status})"
