class PolicyHolder:
    policyholders = {}

    def __init__(self, policyholder_id, name, age, address, status="Active"):
        try:
            self.id = policyholder_id  # Ensuring ID attribute is named 'id'
            self.name = name
            self.age = age
            self.address = address
            self.status = status

            PolicyHolder.policyholders[self.id] = self  # Store in class dictionary
            print(f"✅ PolicyHolder {self.name} (ID: {self.id}) created successfully.")
        except Exception as e:
            print(f"❌ Error creating PolicyHolder: {e}")

    @classmethod
    def register(cls, policyholder_id, name, age, address):
        """Registers a new policyholder if the ID is unique."""
        if policyholder_id in cls.policyholders:
            print(f"⚠️ Policyholder ID {policyholder_id} already exists.")
            return None
        return cls(policyholder_id, name, age, address)

    def suspend(self):
        """Suspends a policyholder's account."""
        if self.status == "Suspended":
            print(f"⚠️ PolicyHolder {self.name} is already suspended.")
        else:
            self.status = "Suspended"
            print(f"🔴 PolicyHolder {self.name} (ID: {self.id}) has been suspended.")

    def activate(self):
        """Reactivates a suspended policyholder."""
        if self.status == "Active":
            print(f"⚠️ PolicyHolder {self.name} is already active.")
        else:
            self.status = "Active"
            print(f"🟢 PolicyHolder {self.name} (ID: {self.id}) has been activated.")

    @classmethod
    def get_policyholder(cls, policyholder_id):
        """Retrieves a policyholder by ID."""
        return cls.policyholders.get(policyholder_id, None)

    def get_details(self):
        """Returns policyholder details in a formatted string."""
        return f"📌 PolicyHolder(ID: {self.id}, Name: {self.name}, Age: {self.age}, Address: {self.address}, Status: {self.status})"

    def __str__(self):
        return self.get_details()
